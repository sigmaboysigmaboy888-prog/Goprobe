package runner

import "fmt"

// Result represents a single positive finding from any runner.
type Result struct {
	// Label is the found word / subdomain / path.
	Label string
	// StatusCode is the HTTP status code (0 for non-HTTP results).
	StatusCode int
	// Size is the response body length in bytes (-1 if unknown).
	Size int64
	// Extra is a free-form detail string shown after the label.
	Extra string
}

// FormatStatus returns a human-readable status string.
func (r Result) FormatStatus() string {
	if r.StatusCode == 0 {
		return r.Extra
	}
	detail := fmt.Sprintf("Status: %d", r.StatusCode)
	if r.Size >= 0 {
		detail += fmt.Sprintf("  Size: %d", r.Size)
	}
	if r.Extra != "" {
		detail += "  " + r.Extra
	}
	return detail
}
