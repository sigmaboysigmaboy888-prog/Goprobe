package runner

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/local/goprobe/internal/output"
	"github.com/local/goprobe/internal/wordlist"
)

// VHostRunner brute-forces virtual hosts by sending requests to a fixed IP/server
// while varying the Host header.
type VHostRunner struct {
	cfg      *Config
	client   *http.Client
	baseSize int64 // size of the baseline (default vhost) response
}

// NewVHostRunner constructs a VHostRunner and measures the baseline response size.
func NewVHostRunner(cfg *Config) (*VHostRunner, error) {
	vr := &VHostRunner{cfg: cfg, client: NewHTTPClient(cfg)}
	if err := vr.measureBaseline(context.Background()); err != nil {
		// Non-fatal: warn and proceed without baseline filtering.
		output.Warn(fmt.Sprintf("baseline measurement failed: %v – all responses will be shown", err))
		vr.baseSize = -1
	}
	return vr, nil
}

func (vr *VHostRunner) measureBaseline(ctx context.Context) error {
	url := strings.TrimRight(vr.cfg.Target, "/")
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return err
	}
	req.Header.Set("User-Agent", vr.cfg.UserAgent)

	resp, err := vr.client.Do(req)
	if err != nil {
		return err
	}
	n, _ := io.Copy(io.Discard, resp.Body)
	resp.Body.Close()
	vr.baseSize = n
	output.Debug(fmt.Sprintf("vhost baseline  url=%s  size=%d", url, n))
	return nil
}

// Run executes vhost brute-force and returns the number of distinct vhosts found.
func (vr *VHostRunner) Run(ctx context.Context) (int, error) {
	words, err := wordlist.Load(vr.cfg.Wordlist)
	if err != nil {
		return 0, err
	}

	appendDomain := vr.cfg.AppendDomain
	total := len(words)
	extraHeaders := vr.cfg.ParseHeaders()
	statusSet := vr.cfg.StatusSet()

	var (
		found int32
		tried int32
		wg    sync.WaitGroup
		sem   = make(chan struct{}, vr.cfg.Threads)
		start = time.Now()
	)

	for _, word := range words {
		select {
		case <-ctx.Done():
			break
		default:
		}

		sem <- struct{}{}
		wg.Add(1)

		go func(w string) {
			defer wg.Done()
			defer func() { <-sem }()

			host := w
			if appendDomain != "" {
				host = w + "." + strings.TrimLeft(appendDomain, ".")
			}

			url := strings.TrimRight(vr.cfg.Target, "/")
			n := int(atomic.AddInt32(&tried, 1))
			output.Progress(n, total, host)

			size, code, loc, err := vr.probe(ctx, url, host, extraHeaders)
			if err != nil {
				output.Debug(fmt.Sprintf("vhost  %s  error: %v", host, err))
				return
			}

			// Filter: skip if response matches baseline size (default vhost).
			if vr.baseSize >= 0 && size == vr.baseSize {
				return
			}

			if len(statusSet) > 0 && !statusSet[code] {
				return
			}

			detail := fmt.Sprintf("Status: %d  Size: %d", code, size)
			if loc != "" {
				detail += "  → " + loc
			}

			output.ClearProgress()
			output.Found(host, detail)
			atomic.AddInt32(&found, 1)
		}(word)
	}

	wg.Wait()
	output.ClearProgress()
	output.Summary("vhost", int(found), int(tried), time.Since(start))
	return int(found), nil
}

func (vr *VHostRunner) probe(
	ctx context.Context,
	url, host string,
	extra http.Header,
) (size int64, code int, location string, err error) {

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return
	}
	req.Host = host
	req.Header.Set("User-Agent", vr.cfg.UserAgent)
	if vr.cfg.Cookies != "" {
		req.Header.Set("Cookie", vr.cfg.Cookies)
	}
	for k, vals := range extra {
		for _, v := range vals {
			req.Header.Set(k, v)
		}
	}

	resp, err := vr.client.Do(req)
	if err != nil {
		return
	}
	n, _ := io.Copy(io.Discard, resp.Body)
	resp.Body.Close()

	size = n
	code = resp.StatusCode
	location = resp.Header.Get("Location")
	return
}
