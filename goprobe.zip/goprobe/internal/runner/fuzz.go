package runner

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/local/goprobe/internal/output"
	"github.com/local/goprobe/internal/wordlist"
)

// FuzzRunner replaces a keyword token inside any part of the request
// (URL path, query string, headers, or POST body) with each wordlist entry.
// Default keyword is FUZZ; override with --fuzz-keyword.
type FuzzRunner struct {
	cfg     *Config
	client  *http.Client
	keyword string
}

// NewFuzzRunner constructs a FuzzRunner.
func NewFuzzRunner(cfg *Config) *FuzzRunner {
	kw := cfg.FuzzKeyword
	if kw == "" {
		kw = "FUZZ"
	}
	return &FuzzRunner{cfg: cfg, client: NewHTTPClient(cfg), keyword: kw}
}

// Run executes the fuzzing loop.
func (r *FuzzRunner) Run(ctx context.Context) (int, error) {
	// Validate that the keyword appears somewhere in the config.
	if !r.keywordPresent() {
		return 0, fmt.Errorf(
			"keyword %q not found in URL, headers, cookies, or post data – nothing to fuzz",
			r.keyword,
		)
	}

	words, err := wordlist.Load(r.cfg.Wordlist)
	if err != nil {
		return 0, err
	}

	extraHeaders := r.cfg.ParseHeaders()
	statusSet := r.cfg.StatusSet()
	total := len(words)

	var (
		found int32
		tried int32
		wg    sync.WaitGroup
		sem   = make(chan struct{}, r.cfg.Threads)
		start = time.Now()
	)

	for _, word := range words {
		select {
		case <-ctx.Done():
			break
		default:
		}

		sem <- struct{}{}
		wg.Add(1)

		go func(w string) {
			defer wg.Done()
			defer func() { <-sem }()

			n := int(atomic.AddInt32(&tried, 1))
			output.Progress(n, total, w)

			res, err := r.probe(ctx, w, extraHeaders)
			if err != nil {
				output.Debug(fmt.Sprintf("fuzz  %s  error: %v", w, err))
				return
			}

			if r.shouldReport(res.StatusCode, statusSet) {
				output.ClearProgress()
				output.Found(w, res.FormatStatus())
				atomic.AddInt32(&found, 1)
			}
		}(word)
	}

	wg.Wait()
	output.ClearProgress()
	output.Summary("fuzz", int(found), int(tried), time.Since(start))
	return int(found), nil
}

func (r *FuzzRunner) keywordPresent() bool {
	if strings.Contains(r.cfg.Target, r.keyword) {
		return true
	}
	if strings.Contains(r.cfg.PostData, r.keyword) {
		return true
	}
	if strings.Contains(r.cfg.Cookies, r.keyword) {
		return true
	}
	for _, h := range r.cfg.Headers {
		if strings.Contains(h, r.keyword) {
			return true
		}
	}
	return false
}

func (r *FuzzRunner) probe(ctx context.Context, word string, extra http.Header) (Result, error) {
	replace := func(s string) string {
		return strings.ReplaceAll(s, r.keyword, word)
	}

	url := replace(r.cfg.Target)
	method := r.cfg.Method
	if method == "" {
		method = http.MethodGet
	}

	var bodyReader io.Reader
	postData := replace(r.cfg.PostData)
	if postData != "" {
		bodyReader = strings.NewReader(postData)
	}

	req, err := http.NewRequestWithContext(ctx, method, url, bodyReader)
	if err != nil {
		return Result{}, err
	}

	req.Header.Set("User-Agent", r.cfg.UserAgent)

	cookies := replace(r.cfg.Cookies)
	if cookies != "" {
		req.Header.Set("Cookie", cookies)
	}

	// Apply extra headers, substituting keyword in both key and value.
	for k, vals := range extra {
		for _, v := range vals {
			rk := strings.ReplaceAll(k, r.keyword, word)
			rv := strings.ReplaceAll(v, r.keyword, word)
			req.Header.Set(rk, rv)
		}
	}

	resp, err := r.client.Do(req)
	if err != nil {
		return Result{}, err
	}
	n, _ := io.Copy(io.Discard, resp.Body)
	resp.Body.Close()

	loc := ""
	if loc = resp.Header.Get("Location"); loc != "" {
		loc = "→ " + loc
	}

	return Result{
		Label:      url,
		StatusCode: resp.StatusCode,
		Size:       n,
		Extra:      loc,
	}, nil
}

func (r *FuzzRunner) shouldReport(code int, set map[int]bool) bool {
	if len(set) == 0 {
		return code != http.StatusNotFound
	}
	return set[code]
}
