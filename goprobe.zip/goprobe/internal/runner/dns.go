package runner

import (
	"context"
	"fmt"
	"net"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/local/goprobe/internal/output"
	"github.com/local/goprobe/internal/wordlist"
)

// DNSRunner brute-forces subdomains via DNS resolution.
type DNSRunner struct {
	cfg      *Config
	resolver *net.Resolver
}

// NewDNSRunner constructs a DNSRunner with an optional custom resolver.
func NewDNSRunner(cfg *Config) *DNSRunner {
	r := &DNSRunner{cfg: cfg}

	if cfg.Resolver != "" {
		addr := cfg.Resolver
		// Ensure resolver address includes a port.
		if !strings.Contains(addr, ":") {
			addr += ":53"
		}
		r.resolver = &net.Resolver{
			PreferGo: true,
			Dial: func(ctx context.Context, network, address string) (net.Conn, error) {
				d := net.Dialer{Timeout: cfg.Timeout}
				return d.DialContext(ctx, "udp", addr)
			},
		}
	} else {
		r.resolver = net.DefaultResolver
	}
	return r
}

// Run executes subdomain brute-force and returns the number of found subdomains.
func (r *DNSRunner) Run(ctx context.Context) (int, error) {
	domain := strings.TrimRight(r.cfg.Target, ".")

	words, err := wordlist.Load(r.cfg.Wordlist)
	if err != nil {
		return 0, err
	}

	// Wildcard detection: resolve a random-looking prefix; if it resolves, flag it.
	wildcard := r.detectWildcard(ctx, domain)
	if wildcard {
		output.Warn(fmt.Sprintf("wildcard DNS detected for %s – false positives possible", domain))
	}

	total := len(words)
	var (
		found int32
		tried int32
		wg    sync.WaitGroup
		sem   = make(chan struct{}, r.cfg.Threads)
		start = time.Now()
	)

	for _, word := range words {
		select {
		case <-ctx.Done():
			break
		default:
		}

		sem <- struct{}{}
		wg.Add(1)

		go func(sub string) {
			defer wg.Done()
			defer func() { <-sem }()

			fqdn := sub + "." + domain
			n := int(atomic.AddInt32(&tried, 1))
			output.Progress(n, total, fqdn)

			addrs, err := r.resolver.LookupHost(ctx, fqdn)
			if err != nil {
				output.Debug(fmt.Sprintf("dns  %s  nxdomain/error: %v", fqdn, err))
				return
			}

			output.ClearProgress()
			output.Found(fqdn, strings.Join(addrs, ", "))
			atomic.AddInt32(&found, 1)
		}(word)
	}

	wg.Wait()
	output.ClearProgress()
	output.Summary("dns", int(found), int(tried), time.Since(start))
	return int(found), nil
}

// detectWildcard sends a resolution for a nonsense subdomain.
func (r *DNSRunner) detectWildcard(ctx context.Context, domain string) bool {
	probe := "goprobe-wildcard-9xq7." + domain
	wctx, cancel := context.WithTimeout(ctx, r.cfg.Timeout)
	defer cancel()
	addrs, err := r.resolver.LookupHost(wctx, probe)
	return err == nil && len(addrs) > 0
}
