package runner

import (
	"bytes"
	"context"
	"encoding/binary"
	"fmt"
	"net"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/local/goprobe/internal/output"
	"github.com/local/goprobe/internal/wordlist"
)

// TFTP opcodes (RFC 1350).
const (
	tftpOpRRQ   = 1
	tftpOpData  = 3
	tftpOpError = 5
)

// TFTPRunner brute-forces file names on a TFTP server.
// It sends a Read Request (RRQ) for each word and considers the file present
// if the server responds with a Data packet (opcode 3) rather than an Error.
type TFTPRunner struct {
	cfg *Config
}

// NewTFTPRunner constructs a TFTPRunner.
func NewTFTPRunner(cfg *Config) *TFTPRunner {
	return &TFTPRunner{cfg: cfg}
}

// Run executes TFTP file discovery.
func (r *TFTPRunner) Run(ctx context.Context) (int, error) {
	words, err := wordlist.Load(r.cfg.Wordlist)
	if err != nil {
		return 0, err
	}

	host := r.cfg.Target
	port := r.cfg.TFTPPort
	if port == 0 {
		port = 69
	}
	addr := fmt.Sprintf("%s:%d", host, port)

	total := len(words)
	var (
		found int32
		tried int32
		wg    sync.WaitGroup
		sem   = make(chan struct{}, r.cfg.Threads)
		start = time.Now()
	)

	for _, word := range words {
		select {
		case <-ctx.Done():
			break
		default:
		}

		sem <- struct{}{}
		wg.Add(1)

		go func(filename string) {
			defer wg.Done()
			defer func() { <-sem }()

			n := int(atomic.AddInt32(&tried, 1))
			output.Progress(n, total, filename)

			exists, err := r.probeFile(ctx, addr, filename)
			if err != nil {
				output.Debug(fmt.Sprintf("tftp  %s  error: %v", filename, err))
				return
			}
			if exists {
				output.ClearProgress()
				output.Found(filename, fmt.Sprintf("server: %s", addr))
				atomic.AddInt32(&found, 1)
			}
		}(word)
	}

	wg.Wait()
	output.ClearProgress()
	output.Summary("tftp", int(found), int(tried), time.Since(start))
	return int(found), nil
}

// probeFile sends a TFTP RRQ and returns true if the server replies with a Data packet.
func (r *TFTPRunner) probeFile(ctx context.Context, addr, filename string) (bool, error) {
	// Build RRQ packet: opcode(2) + filename + 0x00 + "octet" + 0x00
	var pkt bytes.Buffer
	_ = binary.Write(&pkt, binary.BigEndian, uint16(tftpOpRRQ))
	pkt.WriteString(filename)
	pkt.WriteByte(0)
	pkt.WriteString("octet")
	pkt.WriteByte(0)

	conn, err := net.DialTimeout("udp", addr, r.cfg.Timeout)
	if err != nil {
		return false, fmt.Errorf("dial: %w", err)
	}
	defer conn.Close()

	deadline, ok := ctx.Deadline()
	if !ok {
		deadline = time.Now().Add(r.cfg.Timeout)
	}
	_ = conn.SetDeadline(deadline)

	if _, err := conn.Write(pkt.Bytes()); err != nil {
		return false, fmt.Errorf("write: %w", err)
	}

	buf := make([]byte, 516) // max TFTP data packet
	n, err := conn.Read(buf)
	if err != nil {
		// Read timeout = server did not respond = file likely does not exist.
		if netErr, ok := err.(net.Error); ok && netErr.Timeout() {
			return false, nil
		}
		return false, fmt.Errorf("read: %w", err)
	}
	if n < 2 {
		return false, nil
	}

	opcode := binary.BigEndian.Uint16(buf[:2])
	switch opcode {
	case tftpOpData:
		return true, nil
	case tftpOpError:
		// Error packet: file not found or access denied.
		// Decode the error message for debug output.
		msg := ""
		if n > 4 {
			msg = strings.TrimRight(string(buf[4:n]), "\x00")
		}
		output.Debug(fmt.Sprintf("tftp  %s  error_pkt: %s", filename, msg))
		return false, nil
	default:
		return false, nil
	}
}
