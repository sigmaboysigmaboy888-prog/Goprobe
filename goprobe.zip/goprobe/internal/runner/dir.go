package runner

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/local/goprobe/internal/output"
	"github.com/local/goprobe/internal/wordlist"
)

// DirRunner brute-forces directories and files on an HTTP target.
type DirRunner struct {
	cfg    *Config
	client *http.Client
}

// NewDirRunner constructs a ready-to-run DirRunner.
func NewDirRunner(cfg *Config) *DirRunner {
	return &DirRunner{cfg: cfg, client: NewHTTPClient(cfg)}
}

// Run executes the directory brute-force and returns the total number of results found.
func (r *DirRunner) Run(ctx context.Context) (int, error) {
	words, err := wordlist.Load(r.cfg.Wordlist)
	if err != nil {
		return 0, err
	}

	// Build all targets: base word + optional extensions + optional trailing slash.
	targets := r.buildTargets(words)
	total := len(targets)

	baseURL := strings.TrimRight(r.cfg.Target, "/")
	extraHeaders := r.cfg.ParseHeaders()
	statusSet := r.cfg.StatusSet()

	var (
		found   int32
		tried   int32
		wg      sync.WaitGroup
		sem     = make(chan struct{}, r.cfg.Threads)
		start   = time.Now()
	)

	for _, word := range targets {
		select {
		case <-ctx.Done():
			break
		default:
		}

		sem <- struct{}{}
		wg.Add(1)

		go func(w string) {
			defer wg.Done()
			defer func() { <-sem }()

			url := baseURL + "/" + strings.TrimLeft(w, "/")
			res, err := r.probe(ctx, url, extraHeaders)
			n := int(atomic.AddInt32(&tried, 1))

			if err != nil {
				output.Debug(fmt.Sprintf("dir  %s  error: %v", url, err))
				output.Progress(n, total, w)
				return
			}

			output.Progress(n, total, w)

			if r.shouldReport(res.StatusCode, statusSet) {
				output.ClearProgress()
				output.Found(url, res.FormatStatus())
				atomic.AddInt32(&found, 1)
			}
		}(word)
	}

	wg.Wait()
	output.ClearProgress()
	output.Summary("dir", int(found), int(tried), time.Since(start))
	return int(found), nil
}

// buildTargets expands each word into all requested URL variants.
func (r *DirRunner) buildTargets(words []string) []string {
	var out []string
	for _, w := range words {
		out = append(out, w)
		if r.cfg.AddSlash && !strings.HasSuffix(w, "/") {
			out = append(out, w+"/")
		}
		for _, ext := range r.cfg.Extensions {
			e := strings.TrimLeft(ext, ".")
			out = append(out, w+"."+e)
		}
	}
	return out
}

// probe sends a single HTTP request and returns a Result.
func (r *DirRunner) probe(ctx context.Context, url string, extra http.Header) (Result, error) {
	method := r.cfg.Method
	if method == "" {
		method = http.MethodGet
	}

	var bodyReader io.Reader
	if r.cfg.PostData != "" {
		bodyReader = strings.NewReader(r.cfg.PostData)
	}

	req, err := http.NewRequestWithContext(ctx, method, url, bodyReader)
	if err != nil {
		return Result{}, err
	}

	// Default headers.
	req.Header.Set("User-Agent", r.cfg.UserAgent)
	if r.cfg.Cookies != "" {
		req.Header.Set("Cookie", r.cfg.Cookies)
	}
	// Caller-supplied headers override defaults.
	for k, vals := range extra {
		for _, v := range vals {
			req.Header.Set(k, v)
		}
	}

	resp, err := r.client.Do(req)
	if err != nil {
		return Result{}, err
	}
	// Drain and close to return connection to pool.
	n, _ := io.Copy(io.Discard, resp.Body)
	resp.Body.Close()

	loc := ""
	if loc = resp.Header.Get("Location"); loc != "" {
		loc = "→ " + loc
	}

	return Result{
		Label:      url,
		StatusCode: resp.StatusCode,
		Size:       n,
		Extra:      loc,
	}, nil
}

// shouldReport returns true when a status code is reportable given the filter set.
// Default behaviour (empty set): report everything except 404.
func (r *DirRunner) shouldReport(code int, set map[int]bool) bool {
	if len(set) == 0 {
		return code != http.StatusNotFound
	}
	return set[code]
}
