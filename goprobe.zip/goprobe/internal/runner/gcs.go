package runner

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"sync"
	"sync/atomic"
	"time"

	"github.com/local/goprobe/internal/output"
	"github.com/local/goprobe/internal/wordlist"
)

// GCSRunner brute-forces Google Cloud Storage bucket names.
type GCSRunner struct {
	cfg    *Config
	client *http.Client
}

// NewGCSRunner constructs a ready-to-run GCSRunner.
func NewGCSRunner(cfg *Config) *GCSRunner {
	return &GCSRunner{cfg: cfg, client: NewHTTPClient(cfg)}
}

// Run executes GCS bucket discovery.
func (r *GCSRunner) Run(ctx context.Context) (int, error) {
	words, err := wordlist.Load(r.cfg.Wordlist)
	if err != nil {
		return 0, err
	}

	scheme := r.cfg.Scheme
	if scheme == "" {
		scheme = "https"
	}

	total := len(words)
	var (
		found int32
		tried int32
		wg    sync.WaitGroup
		sem   = make(chan struct{}, r.cfg.Threads)
		start = time.Now()
	)

	for _, word := range words {
		select {
		case <-ctx.Done():
			break
		default:
		}

		sem <- struct{}{}
		wg.Add(1)

		go func(bucket string) {
			defer wg.Done()
			defer func() { <-sem }()

			n := int(atomic.AddInt32(&tried, 1))
			output.Progress(n, total, bucket)

			code, detail, err := r.checkBucket(ctx, scheme, bucket)
			if err != nil {
				output.Debug(fmt.Sprintf("gcs  %s  error: %v", bucket, err))
				return
			}

			switch code {
			case http.StatusOK:
				output.ClearProgress()
				output.Found(bucket, "PUBLIC  "+detail)
				atomic.AddInt32(&found, 1)
			case http.StatusForbidden:
				output.ClearProgress()
				output.Found(bucket, "EXISTS (private)  "+detail)
				atomic.AddInt32(&found, 1)
			default:
				output.Debug(fmt.Sprintf("gcs  %s  %d  %s", bucket, code, detail))
			}
		}(word)
	}

	wg.Wait()
	output.ClearProgress()
	output.Summary("gcs", int(found), int(tried), time.Since(start))
	return int(found), nil
}

func (r *GCSRunner) checkBucket(ctx context.Context, scheme, bucket string) (int, string, error) {
	// GCS public URL: https://storage.googleapis.com/<bucket>
	// Also check the bucket-subdomain form: https://<bucket>.storage.googleapis.com
	urls := []string{
		fmt.Sprintf("%s://storage.googleapis.com/%s", scheme, bucket),
		fmt.Sprintf("%s://%s.storage.googleapis.com", scheme, bucket),
	}

	for _, u := range urls {
		req, err := http.NewRequestWithContext(ctx, http.MethodGet, u, nil)
		if err != nil {
			continue
		}
		req.Header.Set("User-Agent", r.cfg.UserAgent)

		resp, err := r.client.Do(req)
		if err != nil {
			continue
		}
		n, _ := io.Copy(io.Discard, resp.Body)
		resp.Body.Close()

		if resp.StatusCode == http.StatusOK || resp.StatusCode == http.StatusForbidden {
			detail := fmt.Sprintf("URL: %s  Size: %d", u, n)
			return resp.StatusCode, detail, nil
		}
	}

	return http.StatusNotFound, "", nil
}
