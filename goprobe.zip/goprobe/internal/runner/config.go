package runner

import (
	"net/http"
	"strings"
	"time"
)

// Config holds all parameters shared across every mode.
type Config struct {
	// Core
	Target   string
	Wordlist string
	Threads  int
	Timeout  time.Duration
	Verbose  bool
	Quiet    bool

	// HTTP behaviour
	StatusCodes    []int  // empty = show all non-404
	StatusCodesRaw string // raw comma list before parsing
	FollowRedirect bool
	UserAgent      string
	Headers        []string // "Key: Value"
	Cookies        string   // raw Cookie header value
	Method         string   // GET, POST, HEAD …
	PostData       string   // body for POST/PUT

	// TLS
	InsecureSkipVerify bool

	// Mode-specific
	// dir / fuzz
	Extensions []string // file extensions to append in dir mode
	AddSlash   bool     // also try /word/
	FuzzKeyword string  // placeholder token in URL (default: FUZZ)

	// dns
	Resolver  string // custom resolver IP:port
	WildcardDNS bool // detected internally

	// vhost
	AppendDomain string // base domain for vhost building

	// s3 / gcs
	Scheme string // https or http

	// tftp
	TFTPHost string
	TFTPPort int
}

// ParseHeaders parses the raw header strings into an http.Header map.
func (c *Config) ParseHeaders() http.Header {
	h := make(http.Header)
	for _, raw := range c.Headers {
		parts := strings.SplitN(raw, ":", 2)
		if len(parts) != 2 {
			continue
		}
		key := strings.TrimSpace(parts[0])
		val := strings.TrimSpace(parts[1])
		h.Add(key, val)
	}
	return h
}

// StatusSet returns the set of allowed status codes as a map for O(1) lookup.
// If the set is empty, callers should apply their own default logic.
func (c *Config) StatusSet() map[int]bool {
	m := make(map[int]bool, len(c.StatusCodes))
	for _, code := range c.StatusCodes {
		m[code] = true
	}
	return m
}
