package runner

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/local/goprobe/internal/output"
	"github.com/local/goprobe/internal/wordlist"
)

// S3Runner brute-forces AWS S3 bucket names using the public REST endpoint.
// It checks both path-style and virtual-hosted-style URLs.
type S3Runner struct {
	cfg    *Config
	client *http.Client
}

// NewS3Runner constructs a ready-to-run S3Runner.
func NewS3Runner(cfg *Config) *S3Runner {
	return &S3Runner{cfg: cfg, client: NewHTTPClient(cfg)}
}

// Run executes S3 bucket discovery and returns the number of buckets found.
func (r *S3Runner) Run(ctx context.Context) (int, error) {
	words, err := wordlist.Load(r.cfg.Wordlist)
	if err != nil {
		return 0, err
	}

	scheme := r.cfg.Scheme
	if scheme == "" {
		scheme = "https"
	}
	region := r.cfg.Target // treat target as AWS region, e.g. "us-east-1"
	if region == "" {
		region = "s3.amazonaws.com"
	}

	total := len(words)
	var (
		found int32
		tried int32
		wg    sync.WaitGroup
		sem   = make(chan struct{}, r.cfg.Threads)
		start = time.Now()
	)

	for _, word := range words {
		select {
		case <-ctx.Done():
			break
		default:
		}

		sem <- struct{}{}
		wg.Add(1)

		go func(bucket string) {
			defer wg.Done()
			defer func() { <-sem }()

			n := int(atomic.AddInt32(&tried, 1))
			output.Progress(n, total, bucket)

			code, detail, err := r.checkBucket(ctx, scheme, region, bucket)
			if err != nil {
				output.Debug(fmt.Sprintf("s3  %s  error: %v", bucket, err))
				return
			}

			// 200 = open/public, 403 = exists but private, anything else = likely not a bucket
			switch code {
			case http.StatusOK:
				output.ClearProgress()
				output.Found(bucket, "PUBLIC  "+detail)
				atomic.AddInt32(&found, 1)
			case http.StatusForbidden:
				output.ClearProgress()
				output.Found(bucket, "EXISTS (private)  "+detail)
				atomic.AddInt32(&found, 1)
			case http.StatusMovedPermanently, http.StatusTemporaryRedirect:
				output.ClearProgress()
				output.Found(bucket, fmt.Sprintf("REDIRECT %d  %s", code, detail))
				atomic.AddInt32(&found, 1)
			default:
				output.Debug(fmt.Sprintf("s3  %s  %d  %s", bucket, code, detail))
			}
		}(word)
	}

	wg.Wait()
	output.ClearProgress()
	output.Summary("s3", int(found), int(tried), time.Since(start))
	return int(found), nil
}

func (r *S3Runner) checkBucket(ctx context.Context, scheme, region, bucket string) (int, string, error) {
	// Virtual-hosted style: https://<bucket>.s3.amazonaws.com
	// For non-us-east-1 regions the host is <bucket>.s3.<region>.amazonaws.com
	var host string
	if strings.HasSuffix(region, "amazonaws.com") {
		host = fmt.Sprintf("%s://%s.%s", scheme, bucket, region)
	} else {
		host = fmt.Sprintf("%s://%s.s3.%s.amazonaws.com", scheme, bucket, region)
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, host, nil)
	if err != nil {
		return 0, "", err
	}
	req.Header.Set("User-Agent", r.cfg.UserAgent)

	resp, err := r.client.Do(req)
	if err != nil {
		return 0, "", err
	}
	n, _ := io.Copy(io.Discard, resp.Body)
	resp.Body.Close()

	loc := resp.Header.Get("Location")
	detail := fmt.Sprintf("URL: %s  Size: %d", host, n)
	if loc != "" {
		detail += "  → " + loc
	}
	return resp.StatusCode, detail, nil
}
