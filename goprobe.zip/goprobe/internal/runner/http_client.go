package runner

import (
	"crypto/tls"
	"net"
	"net/http"
	"time"
)

// NewHTTPClient builds a tuned http.Client for high-concurrency scanning.
// Key design choices:
//   - Global singleton transport with large idle pool – avoids per-request TCP overhead.
//   - DisableKeepAlives=false so connections are reused across goroutines.
//   - TLS InsecureSkipVerify opt-in for self-signed targets.
//   - redirect policy is caller-controlled.
func NewHTTPClient(cfg *Config) *http.Client {
	dialer := &net.Dialer{
		Timeout:   cfg.Timeout,
		KeepAlive: 30 * time.Second,
	}

	transport := &http.Transport{
		DialContext:           dialer.DialContext,
		MaxIdleConns:          cfg.Threads * 4,
		MaxIdleConnsPerHost:   cfg.Threads,
		MaxConnsPerHost:       cfg.Threads,
		IdleConnTimeout:       90 * time.Second,
		TLSHandshakeTimeout:   cfg.Timeout,
		ResponseHeaderTimeout: cfg.Timeout,
		ExpectContinueTimeout: 1 * time.Second,
		TLSClientConfig: &tls.Config{
			InsecureSkipVerify: cfg.InsecureSkipVerify, //nolint:gosec
		},
		DisableCompression: false,
	}

	var checkRedirect func(req *http.Request, via []*http.Request) error
	if !cfg.FollowRedirect {
		checkRedirect = func(_ *http.Request, _ []*http.Request) error {
			return http.ErrUseLastResponse
		}
	}

	return &http.Client{
		Transport:     transport,
		CheckRedirect: checkRedirect,
		Timeout:       cfg.Timeout + 2*time.Second, // belt-and-suspenders outer timeout
	}
}
