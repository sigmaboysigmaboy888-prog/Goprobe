package wordlist

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

// Load reads a wordlist file and returns all non-empty, non-comment lines.
// Lines beginning with '#' are treated as comments and skipped.
func Load(path string) ([]string, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, fmt.Errorf("opening wordlist %q: %w", path, err)
	}
	defer f.Close()

	var words []string
	sc := bufio.NewScanner(f)
	// allow lines up to 1 MB (handles very long fuzz payloads)
	sc.Buffer(make([]byte, 1<<20), 1<<20)

	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		words = append(words, line)
	}
	if err := sc.Err(); err != nil {
		return nil, fmt.Errorf("reading wordlist %q: %w", path, err)
	}
	if len(words) == 0 {
		return nil, fmt.Errorf("wordlist %q is empty", path)
	}
	return words, nil
}

// Stream returns a channel that emits every word in the file,
// closing the channel when EOF is reached or an error occurs.
// The caller receives errors via the returned error channel.
func Stream(path string) (<-chan string, <-chan error) {
	wordCh := make(chan string, 512)
	errCh := make(chan error, 1)

	go func() {
		defer close(wordCh)
		defer close(errCh)

		f, err := os.Open(path)
		if err != nil {
			errCh <- fmt.Errorf("opening wordlist %q: %w", path, err)
			return
		}
		defer f.Close()

		sc := bufio.NewScanner(f)
		sc.Buffer(make([]byte, 1<<20), 1<<20)

		for sc.Scan() {
			line := strings.TrimSpace(sc.Text())
			if line == "" || strings.HasPrefix(line, "#") {
				continue
			}
			wordCh <- line
		}
		if err := sc.Err(); err != nil {
			errCh <- fmt.Errorf("reading wordlist %q: %w", path, err)
		}
	}()

	return wordCh, errCh
}
