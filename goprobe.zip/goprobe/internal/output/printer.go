package output

import (
	"fmt"
	"os"
	"strings"
	"sync"
	"time"
)

// ANSI escape codes – disabled automatically when not a TTY.
const (
	reset  = "\033[0m"
	bold   = "\033[1m"
	green  = "\033[32m"
	yellow = "\033[33m"
	red    = "\033[31m"
	cyan   = "\033[36m"
	grey   = "\033[90m"
)

var (
	mu      sync.Mutex
	isTTY   bool
	verbose bool
	quiet   bool
)

func init() {
	fi, _ := os.Stdout.Stat()
	isTTY = (fi.Mode() & os.ModeCharDevice) != 0
}

// SetVerbose enables debug-level messages.
func SetVerbose(v bool) { verbose = v }

// SetQuiet suppresses everything except found results.
func SetQuiet(q bool) { quiet = q }

func colorize(code, s string) string {
	if !isTTY {
		return s
	}
	return code + s + reset
}

// Banner prints the startup header.
func Banner(mode, target, wordlistPath string, threads int) {
	if quiet {
		return
	}
	mu.Lock()
	defer mu.Unlock()

	fmt.Println()
	fmt.Printf("%s  goprobe  %s\n", colorize(bold+cyan, ">>"), colorize(grey, "fast web & dns recon"))
	fmt.Printf("%s mode       : %s\n", colorize(grey, "  ·"), colorize(yellow, mode))
	fmt.Printf("%s target     : %s\n", colorize(grey, "  ·"), target)
	fmt.Printf("%s wordlist   : %s\n", colorize(grey, "  ·"), wordlistPath)
	fmt.Printf("%s threads    : %d\n", colorize(grey, "  ·"), threads)
	fmt.Printf("%s started    : %s\n", colorize(grey, "  ·"), time.Now().Format("15:04:05"))
	fmt.Println()
}

// Found prints a confirmed result.
func Found(label, detail string) {
	mu.Lock()
	defer mu.Unlock()
	fmt.Printf("%s %s  %s\n",
		colorize(bold+green, "[+]"),
		colorize(bold, label),
		colorize(grey, detail),
	)
}

// Info prints a non-result informational line.
func Info(msg string) {
	if quiet {
		return
	}
	mu.Lock()
	defer mu.Unlock()
	fmt.Printf("%s %s\n", colorize(cyan, "[*]"), msg)
}

// Warn prints a warning.
func Warn(msg string) {
	if quiet {
		return
	}
	mu.Lock()
	defer mu.Unlock()
	fmt.Fprintf(os.Stderr, "%s %s\n", colorize(yellow, "[!]"), msg)
}

// Error prints an error.
func Error(msg string) {
	mu.Lock()
	defer mu.Unlock()
	fmt.Fprintf(os.Stderr, "%s %s\n", colorize(red, "[x]"), msg)
}

// Debug prints only when verbose is true.
func Debug(msg string) {
	if !verbose {
		return
	}
	mu.Lock()
	defer mu.Unlock()
	fmt.Printf("%s %s\n", colorize(grey, "[~]"), msg)
}

// Progress writes a live status line that overwrites itself on a TTY.
// On non-TTY output it is suppressed to avoid polluting pipes.
func Progress(done, total int, current string) {
	if quiet || !isTTY {
		return
	}
	mu.Lock()
	defer mu.Unlock()
	// truncate current word so the line never wraps
	if len(current) > 40 {
		current = current[:37] + "..."
	}
	pct := 0
	if total > 0 {
		pct = done * 100 / total
	}
	line := fmt.Sprintf("\r%s %d/%d (%d%%)  %-42s",
		colorize(grey, "[~]"), done, total, pct, current)
	fmt.Print(line)
}

// ClearProgress erases the progress line on TTYs.
func ClearProgress() {
	if quiet || !isTTY {
		return
	}
	mu.Lock()
	defer mu.Unlock()
	fmt.Printf("\r%s\r", strings.Repeat(" ", 80))
}

// Summary prints a final summary block.
func Summary(mode string, found, tried int, elapsed time.Duration) {
	if quiet {
		return
	}
	mu.Lock()
	defer mu.Unlock()
	fmt.Println()
	fmt.Printf("%s done  mode=%s  found=%s  tried=%d  elapsed=%s\n",
		colorize(bold+cyan, ">>"),
		mode,
		colorize(bold+green, fmt.Sprintf("%d", found)),
		tried,
		elapsed.Round(time.Millisecond),
	)
	fmt.Println()
}
